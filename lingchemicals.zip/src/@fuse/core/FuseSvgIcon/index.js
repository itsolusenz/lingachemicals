export { default } from './FuseSvgIcon';
