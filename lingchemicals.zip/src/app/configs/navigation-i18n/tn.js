const locale = {
  APPLICATIONS: 'Programlar',
  DASHBOARDS: 'கட்டுப்பாட்டு தளம்',
  CALENDAR: 'Takvim',
  ECOMMERCE: 'E-Ticaret',
  ACADEMY: 'Akademi',
  MAIL: 'Posta',
  TASKS: 'Yapılacaklar',
  FILE_MANAGER: 'Dosya Yöneticisi',
  CONTACTS: 'Kişiler',
  CHAT: 'Sohbet',
  SCRUMBOARD: 'Proje',
  NOTES: 'Notlar',
};

export default locale;