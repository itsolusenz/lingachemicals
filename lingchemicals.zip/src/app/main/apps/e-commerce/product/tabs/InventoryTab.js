import TextField from '@mui/material/TextField';
import { Controller, useFormContext } from 'react-hook-form';

function InventoryTab(props) {
  const methods = useFormContext();
  const { control } = methods;

  return (
    <div>
      <Controller
        name="gst-num"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            required
            label="GST Number"
            autoFocus
            id="sku"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />

      <Controller
        name="pan-num "
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Pan Number"
            id="quantity"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />
       <Controller
        name="cin-num"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            required
            label="CIN Number"
            autoFocus
            id="sku"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />

      <Controller
        name="add-details"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Additional Details"
            id="quantity"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />
      
      <Controller
        name="incorporation-date"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Incorporation date"
            id="quantity"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />
    </div>
  );
}

export default InventoryTab;
