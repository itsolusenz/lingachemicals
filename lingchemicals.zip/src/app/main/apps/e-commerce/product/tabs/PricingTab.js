import InputAdornment from '@mui/material/InputAdornment';
import TextField from '@mui/material/TextField';
import { Controller, useFormContext } from 'react-hook-form';

function PricingTab(props) {
  const methods = useFormContext();
  const { control } = methods;

  return (
    <div>

      <Controller
        name="address"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Flat, House no.., Building, Company, Apartment"
            id="priceTaxExcl"
            InputProps={{
              startAdornment: <InputAdornment position="start"></InputAdornment>,
            }}
            type="text"
            variant="outlined"
            autoFocus
            fullWidth
          />
        )}
      />


      <Controller
        name="area address"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Area, Street, Sector, Village"
            id="priceTaxIncl"
            InputProps={{
              startAdornment: <InputAdornment position="start"></InputAdornment>,
            }}
            type="text"
            variant="outlined"
            fullWidth
          />
        )}
      />

      <Controller
        name="Landmark"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Landmark"
            id="taxRate"
            InputProps={{
              startAdornment: <InputAdornment position="start"></InputAdornment>,
            }}
            type="text"
            variant="outlined"
            fullWidth
          />
        )}
      />
      <div className='row'>
        <div className='col-md-6'>
          <Controller
            name="state"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="State"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="text"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
        <div className='col-md-6'>
          <Controller
            name="city"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="City"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="text"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
      </div>
      <div className='row'>
        <div className='col-md-6'>
          <Controller
            name="postcode"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="Postcode"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="text"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
        <div className='col-md-6'>
          <Controller
            name="country"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="Country"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="text"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
      </div>
      <div className='row'>
        <div className='col-md-6'>
          <Controller
            name="phone"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="Phone"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="text"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
        <div className='col-md-6'>
          <Controller
            name="wtsapp"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="Whatsapp Number"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="text"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
      </div>
      <div className='row'>
        <div className='col-md-6'>
          <Controller
            name="website"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="Website"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="text"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
        <div className='col-md-6'>
          <Controller
            name="email"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                className="mt-8 mb-16"
                label="Email"
                id="comparedPrice"
                InputProps={{
                  startAdornment: <InputAdornment position="start"></InputAdornment>,
                }}
                type="email"
                variant="outlined"
              // helperText="Add a compare price to show next to the real price"
              />
            )}
          />
        </div>
      </div>
    </div>
  );
}

export default PricingTab;
