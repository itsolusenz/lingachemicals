import InputAdornment from '@mui/material/InputAdornment';
import TextField from '@mui/material/TextField';
import { Controller, useFormContext } from 'react-hook-form';

function ShippingTab(props) {
  const methods = useFormContext();
  const { control } = methods;

  return (
    <div>
      <Controller
        name="facebook"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            required
            label="Facebook Url"
            autoFocus
            id="sku"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />

      <Controller
        name="twitter"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Twitter Url"
            id="quantity"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />
       <Controller
        name="facebook"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            required
            label="Instagram Url"
            autoFocus
            id="sku"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />

      <Controller
        name="linkedin"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Linkedin Url"
            id="quantity"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />
      
      <Controller
        name="youtube"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            className="mt-8 mb-16"
            label="Youtube Url"
            id="quantity"
            variant="outlined"
            type="text"
            fullWidth
          />
        )}
      />
    </div>
  );
}

export default ShippingTab;
