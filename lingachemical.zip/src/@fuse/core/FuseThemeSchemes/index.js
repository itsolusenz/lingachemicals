export { default } from './FuseThemeSchemes';
